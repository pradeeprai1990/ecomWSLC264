let express = require("express");
const { category } = require("./categoryroute");
const { color } = require("./colorroute");
const { size } = require("./sizeroute");
const { story } = require("./storyroute");
const { slider } = require("./sliderroute");
const { subcategory } = require("./subcatroute");
const { productRoute } = require("./productRoute");
let admin = express();



admin.get("/" , (req,res)=>{
    res.send("welcome  to admin panel");

})
admin.use("/category",category)
admin.use("/subcat" , subcategory)
admin.use("/color" ,color)
admin.use("/size" , size)
admin.use("/story" , story)
admin.use("/slider",slider)
admin.use("/product",productRoute)



module.exports = {admin}